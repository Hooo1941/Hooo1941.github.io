n, m = map(int, input().split())
a = list(map(int, input().split()))

def qp(a, b):
    ret = 1
    while b > 0:
        if b & 1:
            ret = ret * a % m
        a = a * a % m
        b >>= 1
    return ret

def inv(a):
    return qp(a, m - 2)

if n == 2:
    p1 = (1 + a[0] - a[1] + m) * inv(2 - a[1] + m) % m
    p2 = (1 - p1 + m) % m
    print(p1, p2, sep=' ')