n, m, l = map(int, input().split())
a = list(map(int, input().split()))
a.sort()
k = 0
ans = 0
cur = 0
for i in range(l):
    if a[i] // n > k:
        k = a[i] // n
        cur = 0
    if cur == m:
        continue
    ans += 1
    cur += 1
print(ans)