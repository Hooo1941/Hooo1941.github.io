b = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
c = [0, 2, 3, 4, 5, 6, 7, 8, 9]

def chan(s):
    a = []
    for i in s:
        a.append(int(i))
    ret = 0
    a.sort()
    for i in range(10):
        ret += abs(a[i] - b[i])
    return ret

m = input()
ans = 9999999
l = len(m)
for i in range(l - 9):
        ans = min(ans, chan(m[i:i + 10]))
print(ans)