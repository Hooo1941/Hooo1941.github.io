def illegal(c):
    if c.isdigit():
        return False
    if c.islower():
        return False
    if c.isupper():
        return False
    if c in '~!@#$%^&*()_':
        return False
    return True

def t1(s):
    d = 0
    l = 0
    u = 0
    t = 0
    for c in s:
        if c.isdigit():
            d += 1
        if c.islower():
            l += 1
        if c.isupper():
            u += 1
        if c in '~!@#$%^&*()_':
            t += 1
    ans = 0
    if d > 0:
        ans += 1
    if l > 0:
        ans += 1
    if u > 0:
        ans += 1
    if t > 0:
        ans += 1
    return ans

def t2(s):
    a = [0] * 12
    for c in s:
        if c in '~!@#$%^&*()_':
            a['~!@#$%^&*()_'.find(c)] += 1
    ans = 0
    for i in a:
        if i > 0:
            ans += 1
    return ans

T = int(input())
for t in range(T):
    s = input()
    l = len(s)
    if l < 6:
        print(0)
        continue
    ok = True
    for c in s:
        if illegal(c):
            ok = False
            break
    if not ok:
        print(0)
        continue
    if l < 8:
        print(1)
        continue
    if t1(s) < 2:
        print(1)
        continue
    if l >= 12 and (t1(s) == 4 or (t1(s) == 3 and t2(s) >= 3)):
        print(3)
        continue
    print(2)