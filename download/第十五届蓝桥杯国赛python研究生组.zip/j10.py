
import sys
sys.setrecursionlimit(100000000)
import copy
n, m = map(int, input().split())
a = list(map(int, input().split()))

import time
start = time.time()

sum = 0

def dfs(a):
    global sum
    l = len(a)
    if l == 1:
        sum += a[0]
        return
    for i in range(l):
        for j in range(i + 1, l):
            b = a[:] # no deepcopy
            t1 = b[i]
            t2 = b[j]
            del b[j]
            del b[i]
            c = b[:]
            c.append(t1 * t2 % m)
            b.append((t1 + t2) % m)
            dfs(b)
            # del b[-1]
            # b.append(t1 * t2 % m)
            dfs(c)

dfs(a)
print(sum % m)
    
end = time.time()
print(end-start)