n = int(input())
a = list(map(int, input().split()))
last = a[0]
ans = 0

def check(ians, last, cur, nxt, dd):
    print("check: ", ians, last, cur, nxt, dd)
    for i in range(ians - 1):
        m = cur - (nxt - cur + 1) // 2
        nxt = cur
        cur = m
    if nxt - cur > 2 * (cur - last):
        return False
    print("check ok", nxt - cur, cur - last)
    return True

for i in range(2, n):
    cur = a[i - 1]
    nxt = a[i]
    ians = 0
    print(last, cur, nxt)
    clast = last
    while nxt - cur > 2 * (cur - last):
        tmp = cur
        cur = cur + 2 * (cur - last)
        last = tmp
        print(last, cur, nxt)
        ians += 1
    if ians == 0:
        continue
    ans += ians
    l = a[i - 1] + 1
    r = cur
    ok = r
    while l <= r:
        mid = (l + r) // 2
        if check(ians, a[i - 1], mid, nxt, a[i - 1] - clast):
            ok = mid
            r = mid - 1
        else:
            l = mid + 1
    last = ok
print(ans)