import sys
sys.setrecursionlimit(100000000)
n, l = map(int, input().split())
a = list(map(int, input().split()))
b = [0] * l
p = []
dis = [-1] * l
dis[0] = 0
for i in range(n):
    for j in range(i, n):
        b[(a[i] + a[j]) % l] = 1
for i in range(l):
    if b[i] == 1:
        p.append(i)

def dfs(x, d):
    for i in p:
        if dis[(x + i) % l] == -1 or dis[(x + i) % l] > d + 1:
            # print((x + i) % l,  d + 1)
            dis[(x + i) % l] = d + 1
            dfs((x + i) % l, d + 1)


# dfs(0, 0)

from collections import deque
q = deque()
q.append((0, 0))
while q:
    cur = q.popleft()
    x = cur[0]
    d = cur[1]
    for i in p:
        if dis[(x + i) % l] == -1 or dis[(x + i) % l] > d + 1:
            dis[(x + i) % l] = dis[x] + 1
            q.append(((x + i) % l, d + 1))

print(dis[l - 1])