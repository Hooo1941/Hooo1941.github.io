import sys
sys.setrecursionlimit(100000000)
n = int(input())
mp = [[] for _ in range(n + 10)]
ans = [[0,0] for _ in range(n + 10)]

for i in range(2, n + 1):
    t = int(input())
    mp[t].append(i)

def dfs(x):
    ans[x][x % 2] += 1
    for i in mp[x]:
        dfs(i)
        ans[x][0] += ans[i][0]
        ans[x][1] += ans[i][1]

dfs(1)
for i in range(1, n + 1):
    if i % 2 == 1:
        print(ans[i][1])
    else:
        print(ans[i][0])