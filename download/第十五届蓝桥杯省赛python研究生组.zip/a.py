a = []
for i in range(2000):
    x, y, z = input().split()
    z = int(z)
    a.append([x, y, z])
# a.sort(key = lambda l: l[2])
# print(a)
ans = 1
for i in range(2000):
    for j in range(i + 1, 2000):
        if a[j][0] != a[j][1]:
            break
        if a[j][2] - a[j - 1][2] > 1000:
            break
        ans = max(ans, j - i + 1)
print(ans)