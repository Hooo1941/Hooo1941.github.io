MOD = 1000000007

jc = [1, 1]
t = 1
for i in range(2, 200005):
    t = (t * i) % MOD
    jc.append(t)

def qp(x, y):
    ret = 1
    b = x
    while y != 0:
        if y % 2 == 1:
            ret = ret * b % MOD
        b = b * b % MOD
        y //= 2
    return ret

def inv(x):
    return qp(x, MOD - 2)

n, m, T = map(int, input().split())
r = list(map(int, input().split()))
c = list(map(int, input().split()))
rd = dict()
for i in r:
    if i not in rd:
        rd[i] = 1
    else:
        rd[i] = rd[i] + 1
cd = dict()
for i in c:
    if i not in cd:
        cd[i] = 1
    else:
        cd[i] = cd[i] + 1
rd = list(rd.items())
rd.sort(key = lambda x: x[0])
rp = dict()
for i in range(len(rd)):
    rp[rd[i][0]] = i + 1
cd = list(cd.items())
cd.sort(key = lambda x: x[0])
cp = dict()
for i in range(len(cd)):
    cp[cd[i][0]] = i + 1

rld = dict() # 离散化
rlc = [1] # 累乘
t = 1
for i in range(n):
    rld[i + 1] = rp[r[i]]
for i in range(len(rd)):
    t = t * rd[i][1] % MOD
    rlc.append(t)
# print(rld, rlc)

cld = dict()
clc = [1]
t = 1
for i in range(m):
    cld[i + 1] = cp[c[i]]
for i in range(len(cd)):
    t = t * cd[i][1] % MOD
    clc.append(t)
# print(cld, clc)

for i in range(T):
    sr,sc,tr,tc = map(int, input().split())
    if rld[tr] < rld[sr] or cld[tc] < cld[sc] or (rld[sr] == rld[tr] and sr != tr) or (cld[sc] == cld[tc] and sc != tc):
        print(0)
        continue
    sr = rld[sr]
    sc = cld[sc]
    tr = rld[tr]
    tc = cld[tc]
    ans = 1

    # r * c * C^stepr_{stepr+stepc}
    if tr - 1 > sr: # r可以选择的中间点
        ans = ans * rlc[tr - 1] * inv(rlc[sr]) % MOD
        # print('R', rlc[tr - 1] * inv(rlc[sr]) % MOD)
    if tc - 1 > sc: # c可以选择的中间点
        ans = ans * clc[tc - 1] * inv(clc[sc]) % MOD
        # print('T', clc[tc - 1] * inv(clc[sc]) % MOD)
    stepr = tr - sr
    stepc = tc - sc
    # r和c的组合
    # C^m_n = n! / m! / (n-m)!
    ans = ans * jc[stepr + stepc] * inv(jc[stepr]) * inv(jc[stepc]) % MOD
    # print('J', jc[stepr + stepc] * inv(jc[stepr]) * inv(jc[stepc]) % MOD)
    print(ans)