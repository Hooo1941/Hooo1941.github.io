n = int(input())
x = list(map(int, input().split()))
f = list(map(int, input().split()))
m = [[] for _ in range(n + 10)]

for i in range(n):
    if f[i] != -1:
        m[i].append(f[i])
        m[f[i]].append(i)

ans = 0

for i in range(n):
    vis = [1 for _ in range(n + 10)]
    for j in range(len(m[i])):
        vis[m[i][j]] = 0
    for j in range(n):
        if vis[j] == 1:
            ans = max(ans, x[i] ^ x[j])

print(ans)