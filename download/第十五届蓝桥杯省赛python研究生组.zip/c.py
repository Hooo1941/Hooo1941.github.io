n = int(input())
fb = [1, 0, 0, 0, 1, 0, 1, 0, 2, 1]
a = list(map(int, input().split()))

class Node:
    def __init__(self, x, y) -> None:
        self.x = x
        self.y = y

def cal(x):
    sum = 0
    xx = x
    while x != 0:
        sum += fb[x % 10]
        x //= 10
    return Node(xx, sum)

b = []
for i in range(n):
    b.append(cal(a[i]))

Node.__lt__ = lambda self, other: self.x < other.x if self.y == other.y else self.y < other.y
b.sort()

for i in range(n):
    print(b[i].x, end=' ')