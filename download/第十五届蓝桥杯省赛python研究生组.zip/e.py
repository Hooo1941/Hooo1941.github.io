import time
import base64

primes = [1 for _ in range(100010)]
primes[0] = 0
primes[1] = 0
for i in range(2, 100010):
    if primes[i] == 0:
        continue
    for j in range(i * i, 100010, i):
        primes[j] = 0
a = []
for i in range(100010):
    if primes[i] == 1:
        a.append(i)

ans = [0 for _ in range(100010)]
for i in range(2, 100010):
    if primes[i] == 1:
        ans[i] = 1
        continue
    for j in a:
        if j > i:
            break
        if ans[i - j] == 0:
            ans[i] = 1
            break
print(ans)

# str = ''
# for i in range(0, 100000, 7):
#     ch = ans[i] << 6
#     ch += ans[i + 1] << 5
#     ch += ans[i + 2] << 4
#     ch += ans[i + 3] << 3
#     ch += ans[i + 4] << 2
#     ch += ans[i + 5] << 1
#     ch += ans[i + 6]
#     str += chr(ch)
# print(base64.b64encode(str.encode()))