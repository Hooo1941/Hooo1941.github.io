import sys
sys.setrecursionlimit(1000000000)

n, s = map(int, input().split())
a = list(map(int, input().split()))
a.insert(0, 0)
m = [[] for _ in range(n + 10)]
ans = 0
for i in range(n - 1):
    u, v = map(int, input().split())
    m[u].append(v)
    m[v].append(u)

vis = [0 for _ in range(n + 10)]
def dfs(x, root):
    global ans
    if a[x] < a[root] and a[root] % a[x] != 0:
        ans += 1
    for i in m[x]:
        if vis[i] == 0:
            vis[i] = 1
            dfs(i, root)
            vis[i] = 0

from collections import deque
q = deque()
q.append(s)
while len(q) != 0:
    root = q.popleft()
    vis[root] = 1
    dfs(root, root)
    for i in m[root]:
        if vis[i] == 0:
            q.append(i)
    # print(root, ans)

print(ans)