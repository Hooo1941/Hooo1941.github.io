a = 0
b = 1
for i in range(1, 10):
    a += i
    b *= i
    print(i, a - b)

# 3