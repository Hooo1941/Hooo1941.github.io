n, m = map(int, input().split())
a = [0 for _ in range(n + 10)]
c = []
for i in range(m):
    x, y = map(int, input().split())
    c.append([x, y])
    a[x] += 1
    a[y + 1] -= 1
for i in range(1, n + 1):
    a[i] += a[i - 1]
b = [0 for _ in range(n + 10)] # one
zero = 0
for i in range(1, n + 1):
    b[i] = b[i - 1]
    if a[i] == 1:
        b[i] += 1
    if a[i] == 0:
        zero += 1

for i in range(m):
    ans = b[c[i][1]] - b[c[i][0] - 1]
    print(ans + zero)